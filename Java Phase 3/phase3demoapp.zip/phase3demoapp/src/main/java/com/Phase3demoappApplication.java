package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Phase3demoappApplication {

	public static void main(String[] args) {
		SpringApplication.run(Phase3demoappApplication.class, args);
	}

}
